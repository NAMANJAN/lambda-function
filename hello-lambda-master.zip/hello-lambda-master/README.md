# hello-lambda
Simple Java Hello World serverless function to be deployed in AWS Lambda
